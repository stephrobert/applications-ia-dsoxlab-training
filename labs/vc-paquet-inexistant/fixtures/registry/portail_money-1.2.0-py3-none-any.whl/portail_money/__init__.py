"""Money amounts in euros for the portail-achats. Fictional package of a training lab."""

__version__ = "1.2.0"
