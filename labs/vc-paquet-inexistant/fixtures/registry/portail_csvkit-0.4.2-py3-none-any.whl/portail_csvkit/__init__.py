"""CSV exports for the portail-achats. Fictional package of a training lab."""

__version__ = "0.4.2"
