"""Read-only client of the fictional ERP. Fictional package of a training lab."""

__version__ = "3.0.0"
